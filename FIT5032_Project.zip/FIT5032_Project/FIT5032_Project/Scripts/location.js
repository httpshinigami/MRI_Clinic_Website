﻿/**
* This is a simple JavaScript demonstration of how to call MapBox API to load the maps.
* I have set the default configuration to enable the geocoder and the navigation control.
* https://www.mapbox.com/mapbox-gl-js/example/popup-on-click/
*
* @author Jian Liew <jian.liew@monash.edu>
*/
const TOKEN = "pk.eyJ1IjoibWNoZTAwMTIiLCJhIjoiY2xtcDJ2cWtnMHR1MjJscWd1ZWUyaTg3eiJ9.VgZgBEvgvzsxJKwmrw5bRg";
var locations = [];
// The first step is obtain all the latitude and longitude from the HTML
// The below is a simple jQuery selector
$(".coordinates").each(function () {
    var longitude = $(".longitude", this).text().trim();
    var latitude = $(".latitude", this).text().trim();
    var description = $(".description", this).text().trim();
    // Create a point data structure to hold the values.
    var point = {
        "latitude": latitude,
        "longitude": longitude,
        "description": description
    };
    // Push them all into an array.
    locations.push(point);
});
var data = [];
for (i = 0; i < locations.length; i++) {
    var feature = {
        "type": "Feature",
        "properties": {
            "description": locations[i].description,
            "icon": "circle-15"
        },
        "geometry": {
            "type": "Point",
            "coordinates": [locations[i].longitude, locations[i].latitude]
        }
    };
    data.push(feature)
}
var defaultDestination = [locations[0].longitude, locations[0].latitude];
mapboxgl.accessToken = 'pk.eyJ1IjoibWNoZTAwMTIiLCJhIjoiY2xtcDJ2cWtnMHR1MjJscWd1ZWUyaTg3eiJ9.VgZgBEvgvzsxJKwmrw5bRg'
var map = new mapboxgl.Map({
    container: 'map',
    style: 'mapbox://styles/mapbox/streets-v10',
    zoom: 11,
    center: [locations[0].longitude, locations[0].latitude]
});

map.on('load', function () {
    // Add a layer showing the places.
    map.addLayer({
        "id": "places",
        "type": "symbol",
        "source": {
            "type": "geojson",
            "data": {
                "type": "FeatureCollection",
                "features": data
            }
        },
        "layout": {
            "icon-image": "{icon}",
            "icon-allow-overlap": true
        }
    });
    var directions = new MapboxDirections({
        accessToken: mapboxgl.accessToken
    });
    map.addControl(directions, 'top-left');
    directions.setDestination('Monash University Clayton Campus, Wellington Rd, Melbourne, Victoria 3168, Australia');
    //directions.setOrigin('Ronald McDonald House, Melbourne, Victoria 3168, Australia');

    //map.addControl(
    //    new MapboxDirections({
    //        accessToken: mapboxgl.accessToken,
    //        destination: [locations[0].longitude, locations[0].latitude]
    //    }),
    //    'top-left',
    //);

    //map.addControl(new MapboxGeocoder({ accessToken: mapboxgl.accessToken }));;

    map.addControl(new mapboxgl.NavigationControl());
    // When a click event occurs on a feature in the places layer, open a popup at the
    // location of the feature, with description HTML from its properties.
    map.on('click', 'places', function (e) {
        var coordinates = e.features[0].geometry.coordinates.slice();
        var description = e.features[0].properties.description;
        // Ensure that if the map is zoomed out such that multiple
        // copies of the feature are visible, the popup appears
        // over the copy being pointed to.
        while (Math.abs(e.lngLat.lng - coordinates[0]) > 180) {
            coordinates[0] += e.lngLat.lng > coordinates[0] ? 360 : -360;
        }
        new mapboxgl.Popup()
            .setLngLat(coordinates)
            .setHTML(description)
            .addTo(map);
    });
    // Change the cursor to a pointer when the mouse is over the places layer.
    map.on('mouseenter', 'places', function () {
        map.getCanvas().style.cursor = 'pointer';
    });
    // Change it back to a pointer when it leaves.
    map.on('mouseleave', 'places', function () {
        map.getCanvas().style.cursor = '';
    });
});


// Function to show the r
function showRoute() {
    var userAddress = document.getElementById('userAddress').value;
    mapboxgl.accessToken = TOKEN;

    var geocoder = new MapboxGeocoder({
        accessToken: mapboxgl.accessToken,
        mapboxgl: mapboxgl,
    });

    geocoder.query(userAddress, function (error, result) {
        if (error || !result || !result.features || result.features.length === 0) {
            alert('Address not found. Please check your input.');
            return;
        }

        var userLocation = result.features[0].center;
        // Replace these coordinates with your clinic's coordinates
        var clinicCoordinates = [YOUR_CLINIC_LONGITUDE, YOUR_CLINIC_LATITUDE];

        // Use Mapbox Directions API to get the route
        var directions = new MapboxDirections({
            accessToken: mapboxgl.accessToken,
        });

        directions.setOrigin(userLocation);
        directions.setDestination(clinicCoordinates);

        map.addControl(directions, 'top-left');
    });
}

// Attach the showRoute function to the button click event
//document.getElementById('showRouteButton').addEventListener('click', showRoute);