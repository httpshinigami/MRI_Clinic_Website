﻿$(document).ready(function () {
    // Get the current date
    var currentDate = new Date();

    // For date of birth
    $('.datepicker').datepicker({
        format: 'yyyy-mm-dd',
        autoclose: true,
    })
});
