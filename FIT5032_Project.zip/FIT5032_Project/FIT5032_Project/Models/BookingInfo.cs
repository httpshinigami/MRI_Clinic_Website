﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FIT5032_Project.Models
{
    public class BookingInfo
    {
        public string Date { get; set; }
        public int Count { get; set; }
    }
}